#!/bin/bash
# This script runs automatically when the Codespace is created
# It installs Android SDK command line tools silently

set -e

echo "========================================="
echo "  BhaashaBuddy - Android SDK Setup"
echo "========================================="

# ---- Install Android SDK Command Line Tools ----
ANDROID_SDK_ROOT=/opt/android-sdk
CMDLINE_TOOLS_VERSION="11076708"  # Latest stable as of 2025

echo "→ Creating Android SDK directory..."
sudo mkdir -p $ANDROID_SDK_ROOT/cmdline-tools
cd /tmp

echo "→ Downloading Android Command Line Tools..."
wget -q "https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_TOOLS_VERSION}_latest.zip" -O cmdline-tools.zip

echo "→ Extracting..."
sudo unzip -q cmdline-tools.zip -d $ANDROID_SDK_ROOT/cmdline-tools
sudo mv $ANDROID_SDK_ROOT/cmdline-tools/cmdline-tools $ANDROID_SDK_ROOT/cmdline-tools/latest
rm cmdline-tools.zip

# ---- Set permissions ----
sudo chown -R $(whoami) $ANDROID_SDK_ROOT

# ---- Accept licenses ----
echo "→ Accepting Android SDK licenses..."
yes | $ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager --licenses > /dev/null 2>&1 || true

# ---- Install required SDK packages ----
echo "→ Installing Android SDK packages (this takes 3-5 minutes)..."
$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager \
  "platform-tools" \
  "platforms;android-34" \
  "build-tools;34.0.0" \
  --sdk_root=$ANDROID_SDK_ROOT

echo "→ Android SDK setup complete!"

# ---- Install npm dependencies ----
echo "→ Installing Node packages..."
cd /workspaces/bhaashabuddy
npm install

echo ""
echo "✅ Setup complete! You can now run:"
echo "   npm run sync        → Sync web files to Android"
echo "   npm run build-android  → Build debug APK"
echo "   npm run build-release  → Build release AAB for Play Store"
echo ""
