# BhaashaBuddy – Complete Guide
## From GitHub Codespace → Play Store

---

## FOLDER STRUCTURE

```
bhaashabuddy/
├── .devcontainer/
│   ├── devcontainer.json     ← Codespace config (auto-installs Android SDK + Java)
│   └── setup.sh              ← Setup script (runs once on Codespace creation)
├── www/
│   └── index.html            ← Your web app (the marathi-app.html renamed)
├── android/                  ← Created by Capacitor (don't edit manually)
├── package.json
├── capacitor.config.json
├── privacy-policy.html       ← Host this somewhere, Google Play needs the URL
└── gradle.properties.template
```

---

## STEP 1 — CREATE GITHUB REPO

1. Go to github.com → New repository
2. Name it `bhaashabuddy`
3. Make it Public or Private (either works)
4. Clone or upload all these files into it
5. Make sure `www/index.html` exists (copy your marathi-app.html → www/index.html)

---

## STEP 2 — OPEN IN GITHUB CODESPACES

1. On your repo page click green **Code** button
2. Click **Codespaces** tab
3. Click **Create codespace on main**
4. Wait ~5 minutes — it auto-runs `setup.sh` which installs:
   - Node.js 20
   - Java 17
   - Android SDK
   - All npm packages

You'll know it's done when you see "✅ Setup complete!" in terminal.

---

## STEP 3 — INITIALIZE CAPACITOR (only once)

Run these commands in the Codespace terminal:

```bash
# Initialize Capacitor (already configured via capacitor.config.json)
npx cap init "BhaashaBuddy" "com.bhaashabuddy.app" --web-dir www

# Add Android platform (creates the android/ folder)
npx cap add android

# Copy gradle.properties settings
cp gradle.properties.template android/gradle.properties

# Sync your web files into Android project
npx cap sync android
```

---

## STEP 4 — BUILD A DEBUG APK (for testing)

```bash
cd android
./gradlew assembleDebug
```

Your APK will be at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

**To test it:** Right-click the file in Codespace file explorer → Download → Install on your Android phone (enable "Install from unknown sources" in phone settings).

---

## STEP 5 — CREATE RELEASE KEYSTORE (only once, keep this safe!)

```bash
# Run this in your project root (not inside android/)
cd /workspaces/bhaashabuddy

keytool -genkey -v \
  -keystore release.keystore \
  -alias bhaashabuddy \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

It will ask you:
- Keystore password → choose something strong, remember it
- Key password → can be same as keystore password
- Name, city, country → fill anything (for certificate info)

⚠️ **VERY IMPORTANT:**
- Download `release.keystore` and save it somewhere safe (Google Drive, etc)
- Never commit it to GitHub (add to .gitignore)
- If you lose this file, you can NEVER update your app on Play Store

---

## STEP 6 — UPDATE capacitor.config.json WITH YOUR PASSWORDS

Edit `capacitor.config.json`:
```json
"buildOptions": {
  "keystorePath": "release.keystore",
  "keystorePassword": "YOUR_ACTUAL_PASSWORD",
  "keystoreAlias": "bhaashabuddy",
  "keystoreAliasPassword": "YOUR_ACTUAL_PASSWORD"
}
```

---

## STEP 7 — BUILD RELEASE AAB (for Play Store)

```bash
cd /workspaces/bhaashabuddy

# Sync latest web files
npx cap sync android

# Build release AAB (Android App Bundle - what Play Store wants)
cd android
./gradlew bundleRelease
```

Your AAB file will be at:
```
android/app/build/outputs/bundle/release/app-release.aab
```

Download this file — you'll upload it to Play Store.

---

## STEP 8 — SIGN THE RELEASE (if not auto-signed)

If Gradle didn't auto-sign, run:

```bash
cd /workspaces/bhaashabuddy/android/app/build/outputs/bundle/release

jarsigner -verbose \
  -sigalg SHA256withRSA \
  -digestalg SHA-256 \
  -keystore /workspaces/bhaashabuddy/release.keystore \
  app-release.aab \
  bhaashabuddy
```

---

## STEP 9 — DEPLOY WEB APP (GitHub Pages — free)

Your web app can also be published as a website for free:

1. Go to repo Settings → Pages
2. Source: Deploy from branch → main → / (root)
3. Save

Your app will be live at: `https://yourusername.github.io/bhaashabuddy/www/`

Or rename `www/index.html` to root `index.html` and it'll be at:
`https://yourusername.github.io/bhaashabuddy/`

**Host privacy policy there too** (needed for Play Store):
`https://yourusername.github.io/bhaashabuddy/privacy-policy.html`

---

## STEP 10 — PUBLISH TO PLAY STORE

### One-time setup:
1. Go to play.google.com/console
2. Pay $25 registration fee
3. Create Developer account

### Create your app:
1. Click **Create app**
2. App name: BhaashaBuddy
3. Language: English
4. App or game: App
5. Free or paid: Free

### Fill required sections (left sidebar):

**App content:**
- Privacy policy URL: `https://yourusername.github.io/bhaashabuddy/privacy-policy.html`
- Content rating: Fill questionnaire (select "Education", no violence, no adult content)
- Target audience: All ages
- Data safety: Select "No" for everything (you collect no data)

**Store listing:**
- Short description (80 chars): `Learn Marathi phrases & dictionary. Works offline!`
- Full description: Write 2-3 paragraphs about the app
- App icon: 512x512 PNG (design on canva.com)
- Screenshots: Take 2-4 screenshots on your phone or use browser devtools mobile view

**Production track:**
1. Click Production → Create new release
2. Upload your `app-release.aab`
3. Release name: 1.0.0
4. Release notes: "Initial release – Marathi phrasebook and dictionary"
5. Click Review release → Start rollout

Google reviews in 3-7 days for first app. After approval it goes live.

---

## UPDATING THE APP LATER

Whenever you update your `www/index.html`:

```bash
# In Codespace:
npx cap sync android
cd android
./gradlew bundleRelease

# Then upload new AAB to Play Console
# Bump version in android/app/build.gradle:
# versionCode 2  (increment by 1 each release)
# versionName "1.1.0"
```

---

## COMMON ERRORS & FIXES

**"JAVA_HOME not set"**
```bash
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
```

**"SDK location not found"**
```bash
echo "sdk.dir=/opt/android-sdk" > android/local.properties
```

**"Gradle build failed - out of memory"**
```bash
export GRADLE_OPTS="-Xmx4096m"
```

**"./gradlew permission denied"**
```bash
chmod +x android/gradlew
```

---

## COST SUMMARY

| Item | Cost |
|---|---|
| GitHub Codespaces | Free (60hrs/month free) |
| GitHub Pages (web hosting) | Free |
| Google Play registration | $25 one-time |
| Apple App Store (later) | $99/year |
| Everything else | Free |

Total to launch on Android: **$25**
